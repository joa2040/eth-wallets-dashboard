export interface Currency {
  currency: string
}
