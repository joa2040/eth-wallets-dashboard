export interface ExchangeRate {
  user: string,
  currency: string,
  rate: number,
}
